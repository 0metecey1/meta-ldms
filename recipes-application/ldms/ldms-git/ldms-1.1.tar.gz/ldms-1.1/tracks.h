#ifndef __TRACKS_INCLUDE_H__
#define __TRACKS_INCLUDE_H__

void tracks (zsock_t *pipe, void *args);
void tracks_test(bool verbose);
#endif
