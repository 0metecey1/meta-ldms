bb-example
==========

Example Yocto/OpenEmbedded autotooled recipe, building an executable with a depdency on a shared library

